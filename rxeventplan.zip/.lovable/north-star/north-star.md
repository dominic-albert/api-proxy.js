<!-- Lovable wrote this file; it is not part of your task. Keep it, and ask the user before deleting or reverting it. -->

# North star

Show attendees spend their visit with the exhibitors, sessions and meetings that matter to them

## Metric

Attendees who add a recommendation to their event plan each week
