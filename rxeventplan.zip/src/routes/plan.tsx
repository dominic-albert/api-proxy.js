import { createFileRoute } from "@tanstack/react-router";
import { INITIAL_OBJECTIVE, OBJECTIVE_KEY } from "@/lib/objective";
import { useEffect, useRef, useState } from "react";
import { Calendar, MapPin, Heart, Info, Sparkles, Pencil, Download, ChevronDown, AlertCircle, Loader2, Send } from "lucide-react";
import { PlanTabs } from "@/components/PlanTabs";
import { HowDialog } from "@/components/HowDialog";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";


export const Route = createFileRoute("/plan")({
  head: () => ({
    meta: [
      { title: "Your Personalised Event Plan | ABC Paris 2024" },
      { name: "description", content: "Exhibitors matched to your registration info for ABC, 16-18 April 2024, Paris." },
      { property: "og:title", content: "Your Personalised Event Plan | ABC Paris 2024" },
      { property: "og:description", content: "Exhibitors matched to your registration info." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});


const REFINE_QS = [
  { q: "Which clinical areas matter most to you?", options: ["Cardiology", "Diagnostic imaging", "Surgery & robotics", "Infection control"] },
  { q: "What do you want to come away with from this show?", options: ["Run a pilot", "Compare suppliers for a tender", "Find a long-term technology partner"] },
  { q: "What kind of organisation are you buying for?", options: ["Public hospital", "Private clinic group", "Home-care provider", "Research centre"] },
  { q: "Any regions or certifications suppliers must have?", options: ["EU / CE marked", "UK / UKCA", "FDA cleared", "No preference"] },
  { q: "When are you hoping to make a decision?", options: ["Within 3 months", "Within 6 months", "Within a year", "Just exploring"] },
];

const nav = ["About", "Visit", "Exhibit", "Hosted Buyer", "Exhibitor Directory", "Conference Programme", "What's on", "Media Zone", "Help"];

function Index() {
  const [more, setMore] = useState(false);
  const [how, setHow] = useState(false);
  const [objective, setObjective] = useState(INITIAL_OBJECTIVE);
  useEffect(() => { const o = sessionStorage.getItem(OBJECTIVE_KEY); if (o) setObjective(o); }, []);
  const [revisions, setRevisions] = useState(5);
  const [warn, setWarn] = useState(false);
  const [warnMore, setWarnMore] = useState(false);
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState("");
  const [proposed, setProposed] = useState<string | null>(null);
  const [thinking, setThinking] = useState(false);
  const [refining, setRefining] = useState(false);
  const [answers, setAnswers] = useState<string[]>([]);
  const chatRef = useRef<HTMLDivElement>(null);
  useEffect(() => { chatRef.current?.scrollTo({ top: chatRef.current.scrollHeight, behavior: "smooth" }); }, [answers.length]);
  const answerQ = (a: string) => { setAnswers((x) => [...x, a]); setDraft(""); };
  const finishRefine = () => {
    if (!proposed) return;
    const picked = answers.map((a, i) => (a ? { i, a } : null)).filter(Boolean) as { i: number; a: string }[];
    const label = ["clinical focus", "aim", "organisation", "requirements", "decision timeline"];
    const extra = picked.map(({ i, a }) => `${label[i]}: ${a.toLowerCase()}`).join("; ");
    const next = proposed.replace(/\.$/, "") + (extra ? ` (${extra}).` : ".");
    setThinking(true);
    setTimeout(() => { setThinking(false); setObjective(next); setRevisions((r) => r - 1); setEditing(false); setProposed(null); setRefining(false); setAnswers([]); setMore(false); showRecs(); }, 1100);
  };
  const [loadingRecs, setLoadingRecs] = useState(false);
  const showRecs = () => { setLoadingRecs(true); setTimeout(() => { setLoadingRecs(false); window.dispatchEvent(new Event("recs-refreshed")); document.getElementById("recommendations")?.scrollIntoView({ behavior: "smooth" }); }, 1800); };
  const defineObjective = () => {
    const input = draft.trim().replace(/[.\s]+$/, "");
    const lead = input.replace(/^(i('| a)m|i am)\s+(looking|here|attending)\s+(for|to)\s+/i, "");
    const base = proposed ? proposed.replace(/\.$/, "") + `, with a particular focus on ${lead.charAt(0).toLowerCase() + lead.slice(1)}.` : `I am attending this trade show to explore ${lead.charAt(0).toLowerCase() + lead.slice(1)}, meet the exhibitors best placed to support this, and identify partners whose products and evidence meet my organisation's requirements.`;
    setThinking(true);
    setTimeout(() => {
      setThinking(false); setDraft("");
      if (proposed) { setObjective(base); setRevisions((r) => r - 1); setEditing(false); setProposed(null); setRefining(false); setMore(false); showRecs(); }
      else setProposed(base);
    }, 1100);
  };
  return (
    <div className="min-h-screen bg-background">
      <header className="bg-header text-header-foreground">
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-3 px-4 py-4 sm:px-6 sm:py-8">
          <div className="flex min-w-0 items-center gap-3 sm:gap-5">
            <span className="shrink-0 text-3xl font-black tracking-tight sm:text-4xl">a<span className="text-brand">B</span>C</span>
            <div className="min-w-0 space-y-1 border-l border-header-foreground/30 pl-3 text-[11px] sm:space-y-2 sm:pl-5 sm:text-xs">
              <div className="flex items-center gap-1.5 sm:gap-2"><Calendar className="size-3.5 shrink-0 text-brand sm:size-4" />16-18 April 2024</div>
              <div className="flex items-center gap-1.5 sm:gap-2"><MapPin className="size-3.5 shrink-0 text-brand sm:size-4" />Paris, France</div>
            </div>
          </div>
          <div className="flex shrink-0 gap-2 sm:gap-3">
            <button aria-label="Favourites" className="grid size-9 place-items-center bg-brand text-primary-foreground sm:size-10"><Heart className="size-4" /></button>
            <button className="h-9 bg-brand px-3 text-sm font-semibold text-primary-foreground sm:h-10 sm:px-5">Take part</button>
          </div>
        </div>
        <nav className="border-t border-header-foreground/20">
          <ul className="flex gap-5 overflow-x-auto whitespace-nowrap px-4 py-2.5 text-sm [scrollbar-width:none] sm:flex-wrap sm:justify-center sm:px-6">
            {nav.map((n) => (
              <li key={n} className={n === "Conference Programme" ? "underline" : ""}>{n}</li>
            ))}
          </ul>
        </nav>
      </header>

      <main className="mx-auto max-w-6xl px-4 py-5 sm:px-6 sm:py-10">
        <section className="relative overflow-hidden rounded-2xl bg-surface p-4 sm:p-8">
          <div className="pointer-events-none absolute -right-20 -top-24 size-72 rounded-full bg-brand/10 blur-3xl" />
          <div className="relative flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
            <div>
              <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-brand sm:text-xs">ABC Paris · 16–18 April 2024</p>
              <h2 className="mt-1.5 text-2xl font-semibold leading-tight tracking-tight text-foreground sm:mt-2 sm:text-4xl">Your Personalised Event Plan</h2>
              <p className="mt-2 flex flex-wrap items-center gap-1.5 text-sm text-muted-foreground">
                Exhibitors matched to your registration info
                <Info className="size-4" />
                <button type="button" onClick={() => setHow(true)} className="font-medium text-foreground underline underline-offset-4">Learn more</button>
              </p>
            </div>
            <button className="flex h-10 w-fit shrink-0 items-center gap-2 self-end rounded-full border border-brand bg-card px-4 text-sm font-medium text-brand sm:h-auto sm:self-auto sm:px-5 sm:py-2.5"><Download className="size-4" />Download summary</button>
          </div>

          <div className="relative mt-5 rounded-r-xl border-l-4 border-brand bg-card p-4 shadow-[0_1px_8px_var(--border)] sm:mt-6 sm:p-5">
            <div className="flex items-center justify-between gap-3">
              <div className="flex min-w-0 items-center gap-2 font-semibold">
                <span className="grid size-8 shrink-0 place-items-center rounded-full bg-brand/10 text-brand"><Sparkles className="size-4" /></span>
                <span className="truncate">My Show Objective</span>
              </div>
              {<button type="button" disabled={revisions === 0} onClick={() => setWarn(true)} className="flex shrink-0 items-center gap-1 text-sm font-medium text-brand disabled:opacity-40"><Pencil className="size-4" />Edit</button>}
            </div>
            <span className="mt-3 inline-block rounded-full bg-surface px-3 py-1 text-xs text-muted-foreground">Revisions left {revisions}/5</span>
            <>
            <p className={`mt-3 text-sm leading-relaxed text-muted-foreground sm:line-clamp-none ${more ? "" : "line-clamp-4"}`}>
              {objective}
            </p>
            <button type="button" onClick={() => setMore(!more)} className="mt-2 flex items-center gap-1 text-sm font-medium text-brand sm:hidden">
              {more ? "Show less" : "Show more"}<ChevronDown className={`size-4 transition-transform ${more ? "rotate-180" : ""}`} />
            </button>
            </>
          </div>
        </section>

        <div id="recommendations" className="scroll-mt-4"><PlanTabs /></div>
      </main>

      <Dialog open={warn} onOpenChange={(o) => { setWarn(o); if (!o) setWarnMore(false); }}>
        <DialogContent className="rounded-2xl p-6 sm:max-w-xl sm:p-8">
          <DialogHeader className="text-left">
            <DialogTitle className="pr-6 text-2xl font-semibold tracking-tight">Edit Your Personalised Event Plan</DialogTitle>
            <DialogDescription className="sr-only">Review your objective before editing</DialogDescription>
          </DialogHeader>
          <div>
            <h4 className="font-semibold text-foreground">Your current personalised event objective</h4>
            <p className={`mt-1 text-sm leading-relaxed text-foreground sm:text-base ${warnMore ? "" : "line-clamp-4"}`}>{objective}</p>
            <button type="button" onClick={() => setWarnMore(!warnMore)} className="mt-1 flex items-center gap-1 text-sm font-medium text-brand">
              {warnMore ? "Show less" : "Show more"}<ChevronDown className={`size-4 transition-transform ${warnMore ? "rotate-180" : ""}`} />
            </button>
          </div>
          <p className="flex items-start gap-3 rounded-lg bg-destructive/5 p-4 text-sm text-foreground">
            <AlertCircle className="mt-0.5 size-5 shrink-0 text-destructive" />
            <span>Updating the plan replaces current recommendations. Save as PDF if needed. You can change only up to 5 times ({revisions} left).</span>
          </p>
          <div className="flex items-center justify-end gap-2">
            <button type="button" onClick={() => setWarn(false)} className="h-11 rounded-full px-5 text-sm font-medium text-foreground hover:bg-surface">Cancel</button>
            <button type="button" onClick={() => { setDraft(""); setWarn(false); setEditing(true); }} className="h-11 rounded-full bg-brand px-6 text-sm font-medium text-primary-foreground">Proceed to edit</button>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={editing} onOpenChange={(o) => { setEditing(o); if (!o) { setProposed(null); setRefining(false); setAnswers([]); } }}>
        <DialogContent className={`max-h-[94dvh] w-[calc(100%-1rem)] gap-3 overflow-y-auto rounded-2xl p-4 sm:gap-4 sm:p-6 ${proposed && !refining ? "sm:max-w-xl" : "sm:max-w-2xl"} ${proposed && refining ? "flex h-[88dvh] flex-col sm:h-[640px]" : ""}`}>
          <DialogHeader className="text-left">
            <DialogTitle className="pr-6 text-lg font-semibold leading-snug tracking-tight sm:text-xl">{proposed ? (refining ? "Refine your Show Objective" : "Based on your input, we've defined your Show Objective as:") : "Let's Find the Right Exhibitors"}</DialogTitle>
            <DialogDescription className={proposed && !refining ? "sr-only" : "text-sm text-muted-foreground"}>{proposed ? "Tell us a bit more and we'll sharpen your objective." : "Tell us what you're looking to achieve at the event, and we'll recommend exhibitors that match your interests."}</DialogDescription>
          </DialogHeader>
          {proposed && !refining && (<>
            <div className="rounded-xl bg-brand/5 p-4 sm:p-5">
              <h4 className="font-semibold text-foreground">New Objective</h4>
              <p className="mt-2 text-sm italic leading-relaxed text-muted-foreground sm:text-base">{proposed}</p>
            </div>
            <div className="flex flex-col-reverse items-stretch justify-end gap-2 sm:flex-row sm:items-center">
              <button type="button" onClick={() => setRefining(true)} className="h-11 rounded-full px-5 text-sm font-medium text-foreground hover:bg-surface">Refine further</button>
              <button type="button" onClick={() => { setObjective(proposed); setRevisions((r) => r - 1); setEditing(false); setProposed(null); setRefining(false); showRecs(); }}
                className="h-11 rounded-full bg-brand px-6 text-sm font-medium text-primary-foreground shadow-sm transition hover:opacity-90">View new recommendations</button>
            </div>
          </>)}
          {proposed && refining && (<>
            <div className="shrink-0 rounded-lg bg-brand/5 px-3 py-2"><p className="line-clamp-2 overflow-hidden text-xs italic text-muted-foreground"><span className="not-italic font-semibold text-brand">Current: </span>{proposed}</p></div>
            <div className="flex items-center justify-between text-[11px] text-muted-foreground">
              <span>Question {Math.min(answers.length + 1, REFINE_QS.length)} of {REFINE_QS.length}</span>
              <span className="font-medium text-brand">{Math.max(0, revisions - 1)}/5 revisions left</span>
            </div>
            <div className="-mt-1 flex gap-1">{REFINE_QS.map((_, i) => <span key={i} className={`h-1 flex-1 rounded-full ${i < answers.length ? "bg-brand" : "bg-muted"}`} />)}</div>
            <div ref={chatRef} className="-mx-1 min-h-0 flex-1 space-y-2.5 overflow-y-auto px-1">
              {REFINE_QS.slice(0, Math.min(answers.length + 1, REFINE_QS.length)).map((item, i) => (
                <div key={i} className="space-y-1.5">
                  <div className="flex items-start gap-2">
                    <span className="grid size-6 shrink-0 place-items-center rounded-full bg-brand/10 text-brand"><Sparkles className="size-3" /></span>
                    <p className="max-w-[85%] rounded-2xl rounded-tl-sm bg-surface px-3 py-1.5 text-[13px] leading-snug text-foreground">{item.q}</p>
                  </div>
                  {answers[i] !== undefined && (
                    <div className="flex justify-end">
                      <p className={`max-w-[85%] text-right text-[13px] leading-snug ${answers[i] ? "font-medium text-foreground" : "italic text-muted-foreground"}`}>{answers[i] || "Skipped"}</p>
                    </div>
                  )}
                  {i === answers.length && (
                    <div className="flex flex-wrap gap-1.5 pl-8">
                      {item.options.map((o) => (
                        <button key={o} type="button" onClick={() => answerQ(o)} className="rounded-full border border-brand/30 bg-card px-2.5 py-1 text-xs font-medium text-brand transition hover:bg-brand/5">{o}</button>
                      ))}
                      <button type="button" onClick={() => document.getElementById("refine-answer")?.focus()} className="inline-flex items-center gap-1 rounded-full border border-dashed border-border bg-card px-2.5 py-1 text-xs font-medium text-muted-foreground transition hover:border-brand/40 hover:text-brand"><Pencil className="size-3" />Write my own</button>
                    </div>
                  )}
                </div>
              ))}
            </div>
            <div className="-mx-4 -mb-4 shrink-0 space-y-2 border-t border-border bg-background px-4 pb-4 pt-2.5 sm:-mx-6 sm:-mb-6 sm:px-6 sm:pb-5">
            {answers.length < REFINE_QS.length && (
              <div className="flex items-end gap-1 rounded-full border border-input bg-card py-1 pl-3 pr-1 focus-within:border-brand focus-within:ring-2 focus-within:ring-brand/15">
                <textarea value={draft} onChange={(e) => setDraft(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey && draft.trim()) { e.preventDefault(); answerQ(draft.trim()); } }}
                  id="refine-answer" rows={1} maxLength={200} autoFocus placeholder="Type your own answer…" className="max-h-24 min-w-0 flex-1 resize-none bg-transparent py-1.5 text-sm text-foreground outline-none placeholder:text-muted-foreground" />
                <button type="button" onClick={() => answerQ("")} className="h-8 shrink-0 rounded-full px-2.5 text-xs font-medium text-muted-foreground hover:bg-surface">Skip</button>
                <button type="button" aria-label="Send answer" disabled={!draft.trim()} onClick={() => answerQ(draft.trim())} className="grid size-8 shrink-0 place-items-center rounded-full bg-brand text-primary-foreground disabled:bg-muted disabled:text-muted-foreground"><Send className="size-4" /></button>
              </div>
            )}
            <div className="flex items-center justify-between gap-2">
              <button type="button" onClick={() => { setRefining(false); setDraft(""); setAnswers([]); }} className="h-9 rounded-full px-3 text-sm font-medium text-foreground hover:bg-surface">Back</button>
              <button type="button" disabled={!answers.some(Boolean) || thinking} onClick={finishRefine} className="flex h-9 items-center gap-2 rounded-full bg-brand px-5 text-sm font-medium text-primary-foreground disabled:bg-muted disabled:text-muted-foreground">{thinking && <Loader2 className="size-4 animate-spin" />}{thinking ? "Refining…" : answers.length >= REFINE_QS.length ? "Update objective" : "Finish & update"}</button>
            </div>
            </div>
          </>)}
          {!proposed && <div className="grid gap-3 sm:grid-cols-2">
            <div className="rounded-2xl border border-border bg-surface p-4 sm:p-5">
              <h4 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Your objective can include</h4>
              <ul className="mt-3 space-y-2 text-sm text-foreground">
                {["Products or solutions you're interested in", "Industries, brands, or business categories", "Preferred countries or regions"].map((t) => (
                  <li key={t} className="flex gap-2"><span className="mt-1.5 size-1.5 shrink-0 rounded-full bg-brand" />{t}</li>
                ))}
              </ul>
            </div>
            <button type="button" onClick={() => setDraft("I'm looking for remote cardiac monitoring suppliers in Europe and AI-assisted diagnostic imaging solutions.")}
              className="group rounded-2xl border border-brand/20 bg-gradient-to-br from-brand/10 via-brand/5 to-transparent p-4 text-left transition hover:border-brand/50 sm:p-5">
              <h4 className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-brand"><Sparkles className="size-4" />Example</h4>
              <p className="mt-3 text-sm leading-relaxed text-foreground">"I'm looking for remote cardiac monitoring suppliers in Europe and AI-assisted diagnostic imaging solutions."</p>
              <span className="mt-3 inline-block text-xs font-medium text-brand group-hover:underline">Use this example</span>
            </button>
          </div>}
          {!proposed && (<>
          <div>
            <div className="flex items-center justify-between gap-3">
              <h4 className="text-lg font-semibold text-foreground">{proposed ? "Add more detail" : "Let's start defining a new objective for you"}</h4>
              <span className="shrink-0 rounded-full bg-brand/10 px-2.5 py-1 text-xs font-medium text-brand">{Math.max(0, revisions - (proposed ? 1 : 0))}/5 revisions left</span>
            </div>
            <p className="mt-1 text-sm text-muted-foreground">The more details you share, the more relevant your recommendations will be.</p>
            <div className="mt-3 rounded-xl border border-input bg-card transition focus-within:border-brand focus-within:ring-2 focus-within:ring-brand/15">
              <textarea value={draft} onChange={(e) => setDraft(e.target.value)} rows={4} maxLength={200} autoFocus placeholder="Describe what you're looking for..."
                className="block w-full resize-none rounded-xl bg-transparent p-3 text-sm text-foreground outline-none placeholder:text-muted-foreground" />
              <p className="px-3 pb-2 text-right text-xs text-muted-foreground">{draft.length}/200</p>
            </div>
          </div>
          <div className="flex items-center justify-end gap-2">
            
<Popover>
  <PopoverTrigger asChild>
    <button type="button" className="mr-auto inline-flex w-fit items-center gap-1 text-xs font-medium text-brand hover:underline"><Info className="size-3.5" />View current objective</button>
  </PopoverTrigger>
  <PopoverContent align="start" className="w-80 rounded-xl p-3 text-xs leading-relaxed">
    <p className="mb-1 font-semibold text-foreground">Your current objective</p>
    <p className="text-muted-foreground">{objective}</p>
  </PopoverContent>
</Popover>
            <button type="button" onClick={() => (proposed ? (setRefining(false), setDraft("")) : setEditing(false))} className="h-11 rounded-full px-5 text-sm font-medium text-foreground hover:bg-surface">{proposed ? "Back" : "Cancel"}</button>
            <button type="button" disabled={!draft.trim() || thinking} onClick={defineObjective} className="flex h-11 items-center gap-2 rounded-full bg-brand px-6 text-sm font-medium text-primary-foreground disabled:bg-muted disabled:text-muted-foreground">{thinking && <Loader2 className="size-4 animate-spin" />}{thinking ? "Defining…" : "Continue"}</button>
          </div>
          </>)}
        </DialogContent>
      </Dialog>

      {loadingRecs && (
        <div role="status" aria-live="polite" className="fixed inset-0 z-[100] flex flex-col items-center justify-center gap-5 bg-background/90 backdrop-blur-sm">
          <div className="relative flex size-16 items-center justify-center">
            <span className="absolute inset-0 animate-ping rounded-full bg-brand/20" />
            <span className="relative flex size-14 items-center justify-center rounded-full bg-brand/10"><Sparkles className="size-7 animate-pulse text-brand" /></span>
          </div>
          <div className="text-center">
            <p className="text-lg font-semibold text-foreground">Personalising your recommendations…</p>
            <p className="mt-1 text-sm text-muted-foreground">Matching exhibitors, sessions and products to your objective</p>
          </div>
        </div>
      )}

      <HowDialog open={how} onOpenChange={setHow} />
    </div>
  );
}
