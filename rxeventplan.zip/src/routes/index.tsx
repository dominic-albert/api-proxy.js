import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { Calendar, MapPin, Heart, CheckCircle2, CalendarPlus, Hotel, ArrowUp, Presentation, ChevronDown, Sparkles, Linkedin, Twitter, Facebook, Instagram } from "lucide-react";
import { useState } from "react";
import { ArrowRight, Clock3, Lightbulb, LockKeyhole, Play, Star } from "lucide-react";
import { INITIAL_OBJECTIVE, OBJECTIVE_KEY } from "@/lib/objective";
import { Dialog, DialogContent, DialogDescription, DialogTitle } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Pencil } from "lucide-react";
import { HowDialog } from "@/components/HowDialog";
import { Button } from "@/components/ui/button";
import e1 from "@/assets/cards/e1.jpg";
import s1 from "@/assets/cards/s1.jpg";
import p1 from "@/assets/cards/p1.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "You're Registered | ABC Paris 2024" },
      { name: "description", content: "Your ABC Paris 2024 registration, badge and personalised event plan." },
      { property: "og:title", content: "You're Registered | ABC Paris 2024" },
      { property: "og:description", content: "Your badge, add-ons and personalised event plan for ABC Paris." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Registration,
});

const nav = ["About", "Visit", "Exhibit", "Hosted Buyer", "Exhibitor Directory", "Conference Programme", "What's on", "Media Zone", "Help"];

function Registration() {
  const [addons, setAddons] = useState(false);
  const [going, setGoing] = useState(false);
  const [how, setHow] = useState(false);
  const navigate = useNavigate();
  const [confirm, setConfirm] = useState(false);
  const [obj, setObj] = useState(INITIAL_OBJECTIVE);
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState("");
  const goPlan = (e: React.MouseEvent) => {
    e.preventDefault();
    setEditing(false);
    setConfirm(true);
  };
  const proceed = () => {
    sessionStorage.setItem(OBJECTIVE_KEY, obj);
    setConfirm(false);
    setGoing(true);
    setTimeout(() => navigate({ to: "/plan" }), 2000);
  };
  return (
    <div className="min-h-screen bg-background">
      {going && (
        <div role="status" aria-live="polite" className="fixed inset-0 z-[100] flex flex-col items-center justify-center gap-5 bg-background/90 px-6 backdrop-blur-sm">
          <div className="relative flex size-16 items-center justify-center">
            <span className="absolute inset-0 animate-ping rounded-full bg-brand/20" />
            <span className="relative flex size-14 items-center justify-center rounded-full bg-brand/10"><Sparkles className="size-7 animate-pulse text-brand" /></span>
          </div>
          <div className="text-center">
            <p className="text-lg font-semibold text-foreground">Preparing your personalised plan…</p>
            <p className="mt-1 text-sm text-muted-foreground">Matching exhibitors, sessions and products to your objective</p>
          </div>
        </div>
      )}
      <header className="bg-header text-header-foreground">
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-3 px-4 py-4 sm:px-6 sm:py-8">
          <div className="flex min-w-0 items-center gap-3 sm:gap-5">
            <span className="shrink-0 text-3xl font-black tracking-tight sm:text-4xl">a<span className="text-brand">B</span>C</span>
            <div className="min-w-0 space-y-1 border-l border-header-foreground/30 pl-3 text-[11px] sm:space-y-2 sm:pl-5 sm:text-xs">
              <div className="flex items-center gap-1.5 sm:gap-2"><Calendar className="size-3.5 shrink-0 text-brand sm:size-4" />16-18 April 2024</div>
              <div className="flex items-center gap-1.5 sm:gap-2"><MapPin className="size-3.5 shrink-0 text-brand sm:size-4" />Paris, France</div>
            </div>
          </div>
          <div className="flex shrink-0 gap-2 sm:gap-3">
            <button aria-label="Favourites" className="grid size-9 place-items-center bg-brand text-primary-foreground sm:size-10"><Heart className="size-4" /></button>
            <button className="h-9 bg-brand px-3 text-sm font-semibold text-primary-foreground sm:h-10 sm:px-5">Take part</button>
          </div>
        </div>
        <nav className="border-t border-header-foreground/20">
          <ul className="flex gap-5 overflow-x-auto whitespace-nowrap px-4 py-2.5 text-sm [scrollbar-width:none] sm:flex-wrap sm:justify-center sm:px-6">
            {nav.map((n) => <li key={n}>{n}</li>)}
          </ul>
        </nav>
      </header>

      <main className="mx-auto max-w-5xl space-y-6 px-4 py-8 sm:px-6 sm:py-12">
        <section className="grid gap-6 md:grid-cols-2 md:items-center">
          <div>
            <p className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wide text-success"><CheckCircle2 className="size-4" />You're all registered for…</p>
            <h1 className="mt-2 text-2xl font-semibold">ABC Paris 2024</h1>
            <div className="mt-5 flex flex-wrap gap-3">
              <button className="flex h-10 items-center gap-2 rounded-md border border-brand px-4 text-sm font-medium text-brand"><CalendarPlus className="size-4" />Add to Calendar</button>
              <button className="flex h-10 items-center gap-2 rounded-md border border-brand px-4 text-sm font-medium text-brand"><Hotel className="size-4" />Find a Hotel</button>
            </div>
            <p className="mt-5 text-xs leading-relaxed text-muted-foreground">
              Your registration, entry and participation in the Event is subject to the <span className="text-brand">Attendee Terms and Conditions</span>, including the terms of <span className="text-brand">Management's Privacy Policy</span>.
            </p>
          </div>
          <div className="rounded-xl bg-header p-6 text-center text-header-foreground">
            <p className="text-sm font-medium">Badge download ready in…</p>
            <div className="my-5 flex items-start justify-center gap-3 sm:gap-5">
              {[["32", "Days"], ["16", "Hours"], ["54", "Minutes"]].map(([n, l], i) => (
                <div key={l} className="flex items-start gap-3 sm:gap-5">
                  {i > 0 && <span className="pt-2 text-3xl font-bold text-brand sm:text-5xl">:</span>}
                  <div>
                    <div className="text-5xl font-bold tabular-nums sm:text-6xl">{n}</div>
                    <div className="mt-1 text-[11px] font-semibold uppercase tracking-wider text-header-foreground/70">{l}</div>
                  </div>
                </div>
              ))}
            </div>
            <p className="text-xs text-header-foreground/80">You will receive an email notification when your badge is ready!</p>
          </div>
        </section>

        <section className="overflow-hidden rounded-xl border border-border">
          <div className="relative overflow-hidden bg-header p-6 text-header-foreground">
            <div className="pointer-events-none absolute -right-16 top-1/2 size-64 -translate-y-1/2 rounded-full bg-brand/25" />
            <div className="relative">
              <p className="text-sm">My Badge</p>
              <p className="mt-1 text-[10px] font-semibold uppercase tracking-[0.2em] text-header-foreground/70">Customer type</p>
              <h2 className="mt-1 text-xl font-bold sm:text-2xl">Exhibitor Hall Only</h2>
              <p className="mt-1 text-sm text-header-foreground/85">Check what your badge gives access to and upgrade to get the most out of your event.</p>
              <div className="mt-5 flex flex-wrap items-center gap-5">
                <button className="flex h-10 items-center gap-2 rounded-full bg-background px-6 text-sm font-semibold text-foreground ring-2 ring-brand"><ArrowUp className="size-4" />Upgrade</button>
                <button className="flex items-center gap-2 text-sm font-medium"><Presentation className="size-4 text-brand" />Browse Sessions</button>
              </div>
            </div>
          </div>
          <div className="px-6 py-4">
            <button onClick={() => setAddons((v) => !v)} className="flex items-center gap-2 text-sm font-medium">
              <ChevronDown className={`size-4 transition-transform ${addons ? "" : "-rotate-90"}`} />My Add-ons
            </button>
            {addons && <p className="mt-2 pl-6 text-sm text-muted-foreground">You haven't added any extras yet.</p>}
          </div>
        </section>

        <section aria-labelledby="personalised-plan-title" className="plan-promo-frame glow-border p-px">
          <div className="plan-promo-shell relative overflow-hidden bg-plan-promo">
            <div className="relative z-10 p-5 sm:px-6 sm:pb-5 sm:pt-6">
            <div aria-hidden="true" className="plan-promo-calendar absolute right-8 top-8 hidden size-14 rotate-12 items-center justify-center rounded-2xl bg-background text-plan-accent sm:flex"><Calendar className="size-8" /></div>
            <span className="inline-flex items-center gap-2 rounded-full bg-plan-accent-soft px-3 py-1.5 text-[10px] font-bold uppercase text-plan-accent"><Sparkles className="size-3.5" />Ready for you</span>
            <h2 id="personalised-plan-title" className="relative mt-2.5 text-2xl font-bold leading-tight sm:pr-20 sm:text-[28px]">Your Personalised Event Plan</h2>
            <p className="mt-2 text-sm leading-relaxed text-muted-foreground"><span className="font-semibold text-foreground">20 recommendations</span>, ready to be personalised to your objective.</p>
            <div className="relative mt-5 grid gap-2.5 md:grid-cols-[1fr_1fr_0.98fr]">
              {[
                { img: e1, type: "Exhibitor", title: "Nexa Cardio Systems", meta: "Stand ME610" },
                { img: s1, type: "Session", title: "AI in diagnostics", meta: "Day 1 · 10:30" },
              ].map((r) => (
                <Link key={r.type} to="/plan" onClick={goPlan} aria-label={`${r.type} recommendation, locked preview. View my event plan`} className={`plan-preview group relative flex min-h-28 items-center gap-3 overflow-hidden rounded-2xl border border-plan-preview-border bg-background p-3 transition duration-200 hover:border-brand/50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand ${r.type === "Session" ? "plan-preview-session" : ""}`}>
                  <span aria-hidden="true" className="relative flex h-20 w-[66px] shrink-0 items-center justify-center overflow-hidden rounded-lg bg-surface">
                    <img src={r.img} alt="" loading="lazy" className="absolute inset-0 h-full w-full scale-110 object-cover opacity-50 blur-md" />
                    <span className="relative grid size-8 place-items-center rounded-full bg-background/90 text-muted-foreground"><LockKeyhole className="size-3.5" /></span>
                  </span>
                  <div className="relative z-10 min-w-0 flex-1 pr-1">
                    <p className={`mb-1.5 inline-flex items-center gap-1 rounded-md px-1.5 py-1 text-[10px] font-semibold ${r.type === "Exhibitor" ? "bg-brand/10 text-brand" : "bg-plan-session text-plan-session-foreground"}`}>{r.type === "Exhibitor" ? <Star className="size-3" /> : <Play className="size-3" />}{r.type}</p>
                    <p aria-hidden="true" className="select-none text-sm font-bold leading-snug text-muted-foreground/60 blur-[4px]">{r.type === "Exhibitor" ? "Your matched exhibitor" : "Your matched session"}</p>
                    <p aria-hidden="true" className="mt-2 flex select-none items-center gap-1 pr-6 text-[11px] text-muted-foreground/60">{r.type === "Exhibitor" ? <MapPin className="size-3.5 shrink-0" /> : <Clock3 className="size-3.5 shrink-0" />}<span className="blur-[3px]">{r.type === "Exhibitor" ? "Stand details" : "Day · Time"}</span></p>
                  </div>
                  <span className="absolute bottom-3 right-2 grid size-7 place-items-center rounded-full bg-surface text-foreground transition-colors group-hover:bg-brand/10 group-hover:text-brand"><ArrowRight className="size-4" /></span>
                </Link>
              ))}
              <Link to="/plan" onClick={goPlan} className="plan-preview-more group relative flex min-h-28 items-center justify-center gap-3 overflow-hidden rounded-2xl border border-brand/15 p-3 transition duration-200 hover:border-brand/50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand">
                <div className="relative z-10 flex shrink-0 -space-x-3">
                  {[p1, e1, s1].map((im, i) => <span key={i} className="size-9 overflow-hidden rounded-full border-2 border-background bg-surface"><img src={im} alt="" loading="lazy" className="size-full scale-110 object-cover opacity-50 blur-sm" /></span>)}
                </div>
                <div className="relative z-10 min-w-0">
                  <p className="flex items-center gap-2 text-base font-bold text-brand">And more<ArrowRight className="size-3.5 shrink-0 transition-transform motion-safe:group-hover:translate-x-1" /></p>
                  <p className="mt-1 text-[11px] leading-relaxed text-muted-foreground">Exhibitors, sessions &amp; products</p>
                </div>
              </Link>
            </div>
            </div>
            <div className="plan-promo-footer relative z-10 mx-4 mb-4 flex flex-col-reverse gap-3 px-3 py-2 sm:mx-5 sm:flex-row sm:items-center sm:justify-between">
              <Button variant="ghost" type="button" onClick={() => setHow(true)} className="h-auto justify-start gap-2 whitespace-normal px-0 py-1 text-left text-xs font-medium text-plan-accent hover:bg-transparent hover:text-brand"><span className="grid size-8 shrink-0 place-items-center rounded-full bg-plan-accent-soft text-plan-accent"><Lightbulb className="size-4" /></span>Learn how your event plan is generated<ChevronDown className="size-3.5 shrink-0" /></Button>
              <Button asChild className="plan-promo-cta h-11 shrink-0 rounded-full bg-brand px-6 font-semibold text-primary-foreground hover:bg-brand/90">
                <Link to="/plan" onClick={goPlan}>View my event plan<ArrowRight className="size-4" /></Link>
              </Button>
            </div>
          </div>
        </section>

        <section className="py-8 text-center">
          <h2 className="text-xl font-semibold">When &amp; Where?</h2>
          <h3 className="mt-5 font-semibold">Show Dates</h3>
          <div className="mt-2 space-y-2 text-sm">
            <p>Tuesday, 16 April 2024<br /><span className="text-muted-foreground">10:00 AM – 6:00 PM</span></p>
            <p>Wednesday, 17 April 2024<br /><span className="text-muted-foreground">10:00 AM – 6:00 PM</span></p>
            <p>Thursday, 18 April 2024<br /><span className="text-muted-foreground">10:00 AM – 5:00 PM</span></p>
          </div>
          <h3 className="mt-5 font-semibold">Show Location</h3>
          <p className="mt-1 text-sm text-brand">Paris Expo Porte de Versailles</p>
          <p className="text-sm text-muted-foreground">1 Place de la Porte de Versailles, 75015 Paris, France</p>
        </section>
      </main>

      <HowDialog open={how} onOpenChange={setHow} />
      <Dialog open={confirm} onOpenChange={setConfirm}>
        <DialogContent className="max-w-xl gap-0 overflow-hidden rounded-3xl border-0 p-0">
          <div className="relative px-6 pb-5 pt-7 text-center">
            <DialogTitle className="text-xl font-bold text-foreground">Confirm your show objective?</DialogTitle>
            <DialogDescription className="mt-1 text-sm text-muted-foreground">We'll use it to personalise your exhibitors, sessions and products.</DialogDescription>
          </div>
          <div className="px-6 py-5">
            <div className="mb-2 flex items-center justify-between">
              <span className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-brand"><Sparkles className="size-3.5" />Your objective</span>
              {!editing && <button type="button" onClick={() => { setDraft(obj); setEditing(true); }} className="flex items-center gap-1 text-xs font-medium text-brand hover:underline"><Pencil className="size-3.5" />Edit</button>}
            </div>
            {editing ? (
              <div>
                <Textarea autoFocus value={draft} onChange={(e) => setDraft(e.target.value)} rows={6} className="resize-none rounded-2xl text-sm focus-visible:ring-brand" />
                <div className="mt-2 flex justify-end gap-2">
                  <Button variant="ghost" size="sm" onClick={() => setEditing(false)}>Cancel</Button>
                  <Button size="sm" disabled={!draft.trim()} onClick={() => { setObj(draft.trim()); setEditing(false); }} className="bg-brand text-primary-foreground hover:bg-brand/90">Save</Button>
                </div>
              </div>
            ) : (
              <p className="max-h-40 overflow-y-auto rounded-2xl bg-brand/5 p-4 text-sm italic leading-relaxed text-foreground">{obj}</p>
            )}
          </div>
          <div className="flex flex-col-reverse gap-2 border-t px-6 py-4 sm:flex-row sm:justify-end">
            <Button variant="outline" onClick={() => setConfirm(false)} className="rounded-full">Cancel</Button>
            <Button disabled={editing} onClick={proceed} className="plan-promo-cta rounded-full bg-brand text-primary-foreground hover:bg-brand/90"><CheckCircle2 className="size-4" />Yes, show my plan</Button>
          </div>
        </DialogContent>
      </Dialog>
      <footer className="bg-header text-header-foreground">
        <div className="mx-auto max-w-5xl space-y-6 px-4 py-10 sm:px-6">
          <span className="text-3xl font-black tracking-tight">a<span className="text-brand">B</span>C</span>
          <div className="space-y-2 text-xs">
            <div className="flex items-center gap-2"><Calendar className="size-4 text-brand" />16-18 April 2024</div>
            <div className="flex items-center gap-2"><MapPin className="size-4 text-brand" />Paris, France</div>
          </div>
          <div className="flex gap-6 text-brand">
            <Linkedin className="size-5" /><Twitter className="size-5" /><Facebook className="size-5" /><Instagram className="size-5" />
          </div>
          {[
            ["Useful links", ["Contact Us"]],
            ["Policies", ["Terms & Conditions of Use", "Terms of Participation", "Safety, Security and Wellness"]],
            ["Privacy", ["Privacy Policy", "Your Privacy Choices", "Cookie Policy", "Cookie Settings"]],
            ["Built by RX", ["Discover more RX Events", "Latest RX News", "Careers at RX", "RX Inclusion & Diversity", "Accessibility"]],
          ].map(([h, links]) => (
            <div key={h as string}>
              <p className="text-sm font-semibold">{h as string}</p>
              <p className="mt-1 text-xs text-header-foreground/75">{(links as string[]).join("  |  ")}</p>
            </div>
          ))}
          <p className="text-xs underline">Copyright © 2025 RX</p>
        </div>
      </footer>
    </div>
  );
}
